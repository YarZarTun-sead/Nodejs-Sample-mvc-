var db = require('../helpers/database');
//var mysql_1 = global.mysql;

exports.save_user = function(user,cb) {
	//var md5	= require('md5');
	var str = "INSERT INTO `users`(name,email) VALUES ('"+user.name+"','"+user.email+"')";	
	
	db.getConnection(function(err, connection){
		connection.query(str, function(err, result){
			connection.release();
			if(!err){				
				cb(null, "saved Successfully!");
			}else{
			}
		});
	});
}

exports.user_list = function(cb) {
	var str = "SELECT * FROM `users` ORDER BY name";	
	db.getConnection(function(err, connection){
		connection.query(str, function(err, result){
			connection.release();
			if(!err){				
				cb(null, result);
			}else{
				cb(err);
			}
		});
	});
}

exports.user_delete = function(id,cb) {
	var str = "DELETE FROM `users` WHERE id=? ";	
	db.getConnection(function(err, connection){
		connection.query(str,id, function(err, result){
			connection.release();
			if(!err){				
				cb(null,"Delete Successfully");
			}else{
				cb(err);
			}
		});
	});
}

exports.user_update = function(id,name,email,cb) {
	var str = "UPDATE `users` SET `name`=?,`email`=? WHERE `id`=?";	
	db.getConnection(function(err, connection){
		var a=connection.query(str,[name,email,id], function(err, result){
			connection.release();
			if(!err){				
				cb(null,"Update Successfully");
			}else{
				cb(err);
			}
		});
	});
}
