var express = require('express');
var router = express.Router();
console.log("Inside home.js");
var user_model = require('../models/user_model');
router.get('/test', function(req, res) {
	console.log('start in home.');
	res.send("ok");	
});
router.post('/create', function(req, res) {
	console.log("This is View");
	user_model.save_user(req.body,function(err,data){
		res.render('view',{data:data});
	});
});
router.get('/list', function(req, res) {
	console.log("This is List");
	user_model.user_list(function(err,data){
		res.render('list',{data:data});
	});
});
router.get('/delete', function(req, res) {
	var id = req.query.id;
	user_model.user_delete(id,function(err,data){
		res.redirect('/user/list');
	});
});
router.get('/edit', function(req, res) {
	var id = req.query.id;
	res.render('update',{id:id});
});
router.post('/update', function(req, res) {
	var name = req.body.name;
	var email = req.body.email;
	var id = req.body.id;
	user_model.user_update(id,name,email,function(err,data){
		res.redirect('/user/list');
	});
});
module.exports = router;