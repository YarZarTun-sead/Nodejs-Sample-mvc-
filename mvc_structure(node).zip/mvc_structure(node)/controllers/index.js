var express = require('express');
var router = express.Router();

//router.use(require('../middlewares/auth'));

console.log("Inside index.js");
// Front-End system
router.use('/user', require('./home'));
router.get('/', function(req, res) {
	res.render('create');
});
//router.use('/user', require('./user'));
module.exports = router;